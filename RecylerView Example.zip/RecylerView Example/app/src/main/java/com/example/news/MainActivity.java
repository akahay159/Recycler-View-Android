package com.example.news;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    // Create a recycleView Object
    RecyclerView recyclerView;

    @Override
    protected
    void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // user code starts here
        recyclerView = findViewById(R.id.recycleViewid);
        // set for the different layout that is to be used for the user requirements
        recyclerView.setLayoutManager(new LinearLayoutManager(this)); // setting the layout in the recycleview
        //populate the data here [sample data]
        String data[]= {"Java","Android","Python,","C","C++","Linux OS","Kotlin","Steve Jobs","Ms Dhoni"};
        //setting the adapter
        recyclerView.setAdapter(new Adapter(data));


    }
}